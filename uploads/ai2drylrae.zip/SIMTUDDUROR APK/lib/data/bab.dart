class DataBab {
  static const List<Map<String, String>> daftar = [
    {"number": "1", "title": "Asholātul ūlā", "subtitle": "Qasidah 1"},
    {"number": "2", "title": "Asholātus Sānī", "subtitle": "Qasidah 2"},
    {"number": "3", "title": "Inna Fataḥnā", "subtitle": "Fasal 1"},
    {"number": "4", "title": "Assamu'alaik", "subtitle": "Qasidah 3"},
    {"number": "5", "title": "Alḥamdulillāhi", "subtitle": "Fasal 2"},
    {"number": "6", "title": "Tajallal Ḥaqqu", "subtitle": "Fasal 3"},
    {"number": "7", "title": "Wa Asyhadu", "subtitle": "Fasal 4"},
    {"number": "8", "title": "Falammā Ta'allaqot", "subtitle": "Fasal 5"},
    {"number": "9", "title": "Waqod Āna", "subtitle": "Fasal 6"},
    {"number": "10", "title": "Wamundzu 'Aliqot", "subtitle": "Fasal 7"},
    {"number": "11", "title": "Fahīna Quroba", "subtitle": "Fasal 8"},
    {"number": "12", "title": "Maḥallul Qiyām 1", "subtitle": "Dibaca sambil berdiri"},
    {"number": "13", "title": "Maḥallul Qiyām 2", "subtitle": "Dibaca sambil berdiri"},
    {"number": "14", "title": "Wahīna Baroza", "subtitle": "Fasal 9"},
    {"number": "15", "title": "Śumma Innahu", "subtitle": "Fasal 10"},
    // SILAHKAN TAMBAHKAN BAB BARU DI SINI NANTI
  ];
}
