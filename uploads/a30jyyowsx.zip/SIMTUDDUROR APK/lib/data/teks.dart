class IsiTeksMaulid {
  static const List<Map<String, String>> konten = [
    {
      "category": "Asholatul Ula",
      "arabic": "يَا رَبِّ صَلِّ عَلَى مُحَمَّدْ • يَا رَبِّ صَلِّ عَلَيْهِ وَسَلِّمْ\nيَا رَبِّ وَاحْفَظْنَا وَاحْبَابَنَا • فِي كُلِّ حَالٍ يَاحَفِيظُ",
      "latin": "Ya Robbi sholli 'ala Muhammad, Ya Robbi sholli 'alaihi wa sallim.\nYa Robbi wahfazhnā wa aḥbābanā, fī kulli ḥālin yā ḥafīzh.",
      "translation": "Ya Allah, limpahkanlah rahmat kepada Nabi Muhammad. Ya Allah, limpahkanlah rahmat dan salam kepada-Nya.\nYa Allah, jagalah kami dan orang-orang tercinta kami dalam setiap keadaan, wahai Zat yang Maha Menjaga."
    },
    {
      "category": "Inna Fataḥnā",
      "arabic": "إِنَّا فَتَحْنَا لَكَ فَتْحًا مُبِينًا • لِيَغْفِرَ لَكَ اللَّهُ مَا تَقَدَّمَ مِنْ ذَنْبِكَ وَمَا تَأَخَّرَ وَيُتِمَّ نِعْمَتَهُ عَلَيْكَ وَيَهْدِيَكَ صِرَاطًا مُسْتَقِيمًا.",
      "latin": "Inna fataḥnā laka fatḥan mubīnā. Liyaghfiro laka l-lāhu mā taqaddama min żanbika wa mā ta'akhkhara wa yutimma ni'matahu 'alaika wa yahdiyaka shiroṭan mus-taqīmā.",
      "translation": "Sesungguhnya Kami telah memberikan kepadamu kemenangan yang nyata. Supaya Allah mengampuni dosamu yang lalu dan yang akan datang serta menyempurnakan nikmat-Nya atasmu dan memimpin kamu ke jalan yang lurus."
    },
    {
      "category": "Assamu'alaik",
      "arabic": "اَسَّلَامُ عَلَيْكَ يَا زَيْنَ الْأَنْبِيَاءِ • اَسَّلَامُ عَلَيْكَ يَا أْتَقَى الْأَتْقِيَاءِ",
      "latin": "Assalamu'alaika yā zai-nal anbiyā'. Assalamu'alaika yā atqol atqiyā'.",
      "translation": "Salam sejahtera atasmu wahai perhiasan para nabi. Salam sejahtera atasmu wahai sebaik-baik orang yang bertakwa."
    },
    {
      "category": "Alḥamdulillāhi",
      "arabic": "مَعْشَارَ أَوْصَافِ ذَلِكَ الْمَوْصُوفِ. تَشْوِيقًا لِلسَّامِعِينَ. مِنْ خَوَاصِّ الْمُؤْمِنِينَ. وَتَرْوِيحًا لِلْمُتَعَلِّقِينَ بِهَذَا النُّورِ الْمُبِينِ. وَإِلَّا فَأَنَّى تُعْرَبُ الْأَقْلَامُ عَنْ شُؤُونِ خَيْرِ الْأَنَامِ.",
      "latin": "Ma'syāro aushāfi żālikal maushūf. Tasywīqan lis-sāmi'īn. Min khowāshshil mu'minīn. Wa tarwīḥan lil-muta'alliqīna bihāżانِ-nūril mubīn...",
      "translation": "Segala puji bagi Allah... (penjelasan sifat-sifat mulia Baginda Nabi penawar hati orang-orang beriman dan pencinta cahaya yang terang)..."
    },
    {
      "category": "Tajallal Ḥaqqu",
      "arabic": "تَجَلَّى الْحَقُّ فِي عَالَمِ قُدْسِهِ • فَأَشْرَقَتِ الشَّمْسُ مِنْ مَطْلَعِ الْأَزَلِ.",
      "latin": "Tajallal ḥaqqu fī ‘ālimi qudsih, fa asyroqatil syamsu min maṭla'il azal.",
      "translation": "Tampak nyata kebenaran di alam kesucian-Nya, maka bersinarlah matahari dari terbitnya ke azalan."
    },
    {
      "category": "Wa Asyhadu",
      "arabic": "وَأَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ • وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ.",
      "latin": "Wa asyhadu an lā ilāha illallāhu waḥdahu lā syarīka lah, wa asyhadu anna muḥammadan 'abduhu wa rasūluh.",
      "translation": "Dan aku bersaksi bahwa tiada Tuhan selain Allah Yang Maha Esa tiada sekutu bagi-Nya, dan aku bersaksi bahwa Muhammad adalah hamba dan utusan-Nya."
    },
    {
      "category": "Falammā Ta'allaqot",
      "arabic": "فَلَمَّا تَعَلَّقَتْ إِرَادَةُ اللَّهِ الْقَدِيمَةُ • بِإِظْهَارِ حَقِيقَةِ هَذَا النَّبِيِّ الْكَرِيمِ.",
      "latin": "Falammā ta'allaqot irādatullāhil qadīmah, bi izh-hāri ḥaqīqoti hāżan-nabiyyil karīm.",
      "translation": "Maka tatkala berkehendak iradat Allah yang qadim untuk menampakkan hakikat Nabi yang mulia ini."
    },
    {
      "category": "Waqod Āna",
      "arabic": "وَقَدْ آنَ لِلْقَلَمِ أَنْ يَخُطَّ فِي سُطُورِ الْبَيَانِ • مَا أَنْعَمَ اللَّهُ بِهِ عَلَى هَذَا الْإِنْسَانِ.",
      "latin": "Waqod āna lil-qolami an yakhuṭṭa fī suṭūril bayān, mā an'amal-lāhu bihi 'alā hāżal insān.",
      "translation": "Dan telah tiba saatnya bagi pena untuk menggoreskan di baris-baris penjelasan tentang apa yang Allah anugerahkan kepada insan mulia ini."
    },
    {
      "category": "Wamundzu 'Aliqot",
      "arabic": "وَمُنْذُ عَلِقَتْ بِهِ هَذِهِ الدُّرَّةُ الْيَتِيمَةُ • فِي صُلَبِ آدَمَ وَنُوحٍ وَإِبْرَاهِيمَ.",
      "latin": "Wamundzu ‘aliqot bihi hāżihid-durratul yatīmah, fī ṣulbi ādam wa nūḥin wa ibrāhīm.",
      "translation": "Dan semenjak mutiara yang berharga ini bersemayam di sulbi Adam, Nuh, dan Ibrahim."
    },
    {
      "category": "Fahīna Quroba",
      "arabic": "فَحِينَ قُرُبَ أَوَانُ وَضْعِ هَذَا الْحَبِيبِ • ظَهَرَتْ عَلَى أُمِّهِ بَوَاشِيرُ الْقَبُولِ.",
      "latin": "Fahīna quruBa awānu waḍ‘i hāżal habīb, zohorat ‘alā ummihi bawāsyirul qobul.",
      "translation": "Maka ketika hampir tiba waktu kelahiran kekasih ini, tampaklah pada ibunya tanda-tanda keagungan penerimaan."
    },
    {
      "category": "Maḥallul Qiyām 1",
      "arabic": "يَا نَبِي سَلَامٌ عَلَيْكَ • يَا رَسُول سَلَامٌ عَلَيْكَ\nيَا حَبِيب سَلَامٌ عَلَيْكَ • صَلَوَاتُ اللَّهِ عَلَيْكَ",
      "latin": "Yā nabī salām ‘alaika, yā rasūl salām ‘alaika.\nYā ḥabīb salām ‘alaika, sholawatullāh ‘alaika.",
      "translation": "Wahai Nabi, salam sejahtera untukmu. Wahai Rasul, salam sejahtera untukmu.\nWahai Kekasih, salam sejahtera untukmu. Rahmat Allah semoga terlimpah atasmu."
    },
    {
      "category": "Maḥallul Qiyām 2",
      "arabic": "مَرْحَبًا يَا مَرْحَبًا جَدَّ الْحُسَيْنِ • مَرْحَبًا يَانُورَ الْعُيُونِ مَرْحَبًا",
      "latin": "Marḥaban yā marḥaban jaddal ḥusain, marḥaban yā nūral ‘uyūni marḥaba.",
      "translation": "Selamat datang wahai kakek Husain, selamat datang wahai cahaya mata."
    },
    {
      "category": "Wahīna Baroza",
      "arabic": "وَحِينَ بَرَزَ اللَّهُ عَلَيْهِ وَسَلَّمَ إِلَى وِعَاءِ الدُّنْيَا • كَانَ كَالْبَدْرِ الْمُنِيرِ.",
      "latin": "Wahīna baroza ‘alaihi wa sallama ilā wi‘āid-dunyā, kāna kal-badril munīr.",
      "translation": "Dan tatkala baginda shallallahu 'alaihi wa sallam nampak ke alam dunia, bagaikan bulan purnama yang terang benderang."
    },
    {
      "category": "Śumma Innahu",
      "arabic": "ثُمَّ إِنَّهُ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ وَتَقَدَّمَ فِي مَرَاتِبِ الْكَمَالِ • إِلَى أَنْ حَازَ قَابَ قَوْسَيْنِ أَوْ أَدْنَى.",
      "latin": "Śumma innahu shollallāhu ‘alaihi wa sallama wa taqaddama fī marātibil kamāl, ilā an ḥāza qoba qَوْsaini au adnā.",
      "translation": "Kemudian sesungguhnya beliau shallallahu 'alaihi wa sallam terus meningkat dalam martabat kesempurnaan, hingga mencapai kedudukan qaba qausaini atau lebih dekat."
    },
    // SILAHKAN TAMBAHKAN KONTEN TEKS BARU DI SINI NANTI
  ];
}
