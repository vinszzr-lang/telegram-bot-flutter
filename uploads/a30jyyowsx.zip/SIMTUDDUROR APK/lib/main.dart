import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'data/bab.dart';
import 'data/teks.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeFormatting('id_ID', null);
  runApp(const SimtuddurorApp());
}

class SimtuddurorApp extends StatefulWidget {
  const SimtuddurorApp({super.key});

  @override
  State<SimtuddurorApp> createState() => _SimtuddurorAppState();
}

class _SimtuddurorAppState extends State<SimtuddurorApp> {
  // Default awal masuk aplikasi wajib Tema Terang (isDarkMode = false)
  bool _isDarkMode = false;

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Maulid Simtudduror',
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF7F9F8),
        primaryColor: const Color(0xFF1B5E20),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black, // ✅ Judul Bar Hitam Pekat di Mode Terang
          elevation: 1,
          iconTheme: IconThemeData(color: Colors.black87),
          titleTextStyle: TextStyle(
            color: Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        primaryColor: const Color(0xFF1E1E1E),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E1E1E),
          foregroundColor: Colors.white,
          elevation: 1,
          iconTheme: IconThemeData(color: Colors.white),
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      themeMode: _isDarkMode ? ThemeMode.dark : ThemeMode.light,
      home: HomeScreen(onToggleTheme: _toggleTheme, isDarkMode: _isDarkMode),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatelessWidget {
  final VoidCallback onToggleTheme;
  final bool isDarkMode;

  const HomeScreen({super.key, required this.onToggleTheme, required this.isDarkMode});

  // ✅ Fungsi untuk mengambil Hari dan Tanggal Real-Time Saat Ini
  String getFormattedDate() {
    final now = DateTime.now();
    return DateFormat('EEEE, d MMMM yyyy', 'id_ID').format(now);
  }

  // Fungsi untuk mencari teks berdasarkan kategori title bab
  Map<String, String>? _findTeksByTitle(String title) {
    try {
      return IsiTeksMaulid.konten.firstWhere(
        (item) => item['category'] == title,
      );
    } catch (e) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Header Atas: Tombol Tema di Kiri, Tanggal Real-Time di Tengah
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: Icon(
                      isDarkMode ? Icons.light_mode : Icons.dark_mode,
                      color: isDarkMode ? Colors.white : Colors.black87,
                    ),
                    onPressed: onToggleTheme,
                    tooltip: 'Ubah Tema Gelap/Terang',
                  ),
                  // ✅ Tanggal & Hari Dinamis Real-Time
                  Text(
                    getFormattedDate(),
                    style: TextStyle(
                      fontSize: 14,
                      color: isDarkMode ? Colors.white : Colors.black87, // ✅ Kelihatan di mode terang
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
            ),

            // ✅ KALIGRAFI SHOLAWAT ESTETIS (SUPER GEDE, TEBAL & BERFRAME)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
                decoration: BoxDecoration(
                  color: isDarkMode ? const Color(0xFF1E1E1E) : Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: Colors.amber.shade700,
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.amber.withOpacity(0.12),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      '﴿ ۝ ﴾',
                      style: TextStyle(
                        color: Colors.amber.shade800,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَيْهِ وَعَلَى آلِهِ',
                      textAlign: TextAlign.center,
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        fontFamily: 'serif',
                        fontSize: 28, // ✅ Ukuran Super Gede
                        fontWeight: FontWeight.w900, // ✅ Extra Tebal
                        height: 1.6,
                        letterSpacing: 1.2,
                        color: isDarkMode ? Colors.white : Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '﴿ ۝ ﴾',
                      style: TextStyle(
                        color: Colors.amber.shade800,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'SIMTUDDUROR',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2.0,
                        color: isDarkMode ? Colors.green[400] : Colors.green[800],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),

            // List Daftar Bab (Tersinkronisasi otomatis dengan category di teks.dart)
            Expanded(
              child: ListView.builder(
                itemCount: DataBab.daftar.length,
                itemBuilder: (context, index) {
                  final bab = DataBab.daftar[index];
                  final matchedTeks = _findTeksByTitle(bab['title']!);

                  if (matchedTeks == null) {
                    return const SizedBox.shrink();
                  }

                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: isDarkMode ? const Color(0xFF1E1E1E) : Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isDarkMode ? Colors.grey[800]! : Colors.grey[300]!,
                        width: 0.8,
                      ),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      leading: Container(
                        width: 32,
                        height: 32,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: isDarkMode ? Colors.grey[800] : Colors.grey[200],
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          bab['number']!,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: isDarkMode ? Colors.white : Colors.black87,
                            fontSize: 13,
                          ),
                        ),
                      ),
                      title: Text(
                        bab['title']!,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: isDarkMode ? Colors.white : Colors.black,
                        ),
                      ),
                      subtitle: Text(
                        bab['subtitle']!,
                        style: TextStyle(
                          fontSize: 12,
                          color: isDarkMode ? Colors.white60 : Colors.grey[600],
                        ),
                      ),
                      trailing: SizedBox(
                        width: 120,
                        child: Text(
                          matchedTeks['arabic']!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.right, // ✅ RTL Mulai Kanan
                          style: TextStyle(
                            fontFamily: 'serif',
                            fontSize: 16,
                            fontWeight: FontWeight.w800, // ✅ Arab Tebal
                            color: isDarkMode ? Colors.white : Colors.black,
                          ),
                        ),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ReaderScreen(
                              initialIndex: index,
                              isDarkMode: isDarkMode,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Halaman Membaca Teks Lengkap dengan Tab Bar Geser
class ReaderScreen extends StatefulWidget {
  final int initialIndex;
  final bool isDarkMode;

  const ReaderScreen({super.key, required this.initialIndex, required this.isDarkMode});

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: DataBab.daftar.length,
      initialIndex: widget.initialIndex,
      vsync: this,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.isDarkMode ? const Color(0xFF121212) : const Color(0xFFF7F9F8),
      appBar: AppBar(
        backgroundColor: widget.isDarkMode ? const Color(0xFF1E1E1E) : const Color(0xFF1B5E20),
        foregroundColor: Colors.white,
        title: Text(
          DataBab.daftar[_tabController.index]['title']!,
          style: const TextStyle(fontSize: 16, color: Colors.white),
        ),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: Colors.amber,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
          tabs: DataBab.daftar.map((bab) => Tab(text: bab['title'])).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: List.generate(DataBab.daftar.length, (index) {
          final bab = DataBab.daftar[index];
          try {
            final teks = IsiTeksMaulid.konten.firstWhere((item) => item['category'] == bab['title']);
            return ChapterContentView(
              title: bab['title']!,
              contentData: teks,
              isDarkMode: widget.isDarkMode,
            );
          } catch (e) {
            return const Center(child: Text('Teks belum tersedia'));
          }
        }),
      ),
    );
  }
}

class ChapterContentView extends StatefulWidget {
  final String title;
  final Map<String, String> contentData;
  final bool isDarkMode;

  const ChapterContentView({super.key, required this.title, required this.contentData, required this.isDarkMode});

  @override
  State<ChapterContentView> createState() => _ChapterContentViewState();
}

class _ChapterContentViewState extends State<ChapterContentView> {
  bool _showLatin = true;
  bool _showTranslation = true;

  double _arabicFontSize = 26.0;
  double _latinFontSize = 15.0;
  double _translationFontSize = 14.0;

  void _showSettingsModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: widget.isDarkMode ? const Color(0xFF1E1E1E) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Container(
              padding: const EdgeInsets.all(20),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Pengaturan Teks & Ukuran Font',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: widget.isDarkMode ? Colors.white : Colors.black,
                      ),
                    ),
                    const Divider(height: 20),
                    SwitchListTile(
                      title: Text('Tampilkan Teks Biasa (Latin)', style: TextStyle(color: widget.isDarkMode ? Colors.white : Colors.black)),
                      value: _showLatin,
                      activeColor: Colors.green,
                      onChanged: (val) {
                        setModalState(() => _showLatin = val);
                        setState(() => _showLatin = val);
                      },
                    ),
                    SwitchListTile(
                      title: Text('Tampilkan Terjemahan', style: TextStyle(color: widget.isDarkMode ? Colors.white : Colors.black)),
                      value: _showTranslation,
                      activeColor: Colors.green,
                      onChanged: (val) {
                        setModalState(() => _showTranslation = val);
                        setState(() => _showTranslation = val);
                      },
                    ),
                    const Divider(height: 20),
                    _buildFontSlider('Ukuran Font Arab', _arabicFontSize, 20.0, 40.0, (val) {
                      setModalState(() => _arabicFontSize = val);
                      setState(() => _arabicFontSize = val);
                    }),
                    _buildFontSlider('Ukuran Font Latin', _latinFontSize, 12.0, 24.0, (val) {
                      setModalState(() => _latinFontSize = val);
                      setState(() => _latinFontSize = val);
                    }),
                    _buildFontSlider('Ukuran Font Terjemahan', _translationFontSize, 12.0, 24.0, (val) {
                      setModalState(() => _translationFontSize = val);
                      setState(() => _translationFontSize = val);
                    }),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildFontSlider(String label, double value, double min, double max, ValueChanged<double> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: ${value.toStringAsFixed(0)}', style: TextStyle(fontWeight: FontWeight.w500, color: widget.isDarkMode ? Colors.white70 : Colors.black87)),
          Row(
            children: [
              Text('A-', style: TextStyle(fontSize: 12, color: widget.isDarkMode ? Colors.white60 : Colors.black54)),
              Expanded(
                child: Slider(
                  value: value,
                  min: min,
                  max: max,
                  divisions: ((max - min) ~/ 2).toInt(),
                  label: value.toStringAsFixed(0),
                  onChanged: onChanged,
                ),
              ),
              Text('A+', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: widget.isDarkMode ? Colors.white : Colors.black)),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(40),
        child: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0,
          backgroundColor: Colors.transparent,
          actions: [
            PopupMenuButton<String>(
              icon: Icon(Icons.more_vert, color: widget.isDarkMode ? Colors.white : Colors.black87),
              onSelected: (value) {
                if (value == 'settings') {
                  _showSettingsModal(context);
                }
              },
              itemBuilder: (BuildContext context) => [
                const PopupMenuItem<String>(
                  value: 'settings',
                  child: Row(
                    children: [
                      Icon(Icons.settings, size: 18),
                      SizedBox(width: 10),
                      Text('Atur Teks & Font'),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Card(
            elevation: widget.isDarkMode ? 0 : 2,
            color: widget.isDarkMode ? const Color(0xFF1E1E1E) : Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(18.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    widget.title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: widget.isDarkMode ? Colors.green[400] : Colors.green[800],
                      fontSize: 16,
                    ),
                  ),
                  const Divider(height: 20),
                                    // 1. BLOK ARAB FULL (Directionality RTL & Font Arab Tebal)
                  Directionality(
                    textDirection: TextDirection.rtl, // ✅ Mulai dari kanan ke kiri
                    child: Text(
                      widget.contentData['arabic']!,
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontSize: _arabicFontSize,
                        fontFamily: 'serif',
                        fontWeight: FontWeight.w800, // ✅ Font Arab Tebal Harokat Jelas
                        height: 2.2,
                        color: widget.isDarkMode ? Colors.white : Colors.black87,
                      ),
                    ),
                  ),

                  // 2. BLOK LATIN FULL
                  if (_showLatin) ...[
                    const SizedBox(height: 24),
                    Divider(thickness: 1, color: widget.isDarkMode ? Colors.grey[800] : Colors.grey[300]),
                    const SizedBox(height: 12),
                    Text(
                      widget.contentData['latin']!,
                      style: TextStyle(
                        fontSize: _latinFontSize,
                        fontStyle: FontStyle.italic,
                        height: 1.5,
                        color: widget.isDarkMode ? Colors.white70 : Colors.black87,
                      ),
                    ),
                  ],

                  // 3. BLOK TERJEMAHAN FULL
                  if (_showTranslation) ...[
                    const SizedBox(height: 24),
                    Divider(thickness: 1, color: widget.isDarkMode ? Colors.grey[800] : Colors.grey[300]),
                    const SizedBox(height: 12),
                    Text(
                      widget.contentData['translation']!,
                      style: TextStyle(
                        fontSize: _translationFontSize,
                        color: widget.isDarkMode ? Colors.white60 : Colors.grey[700],
                        height: 1.5,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
                   